"""Regression cases for decision authority, claim scope and regeneration."""

import copy
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
MODULE = ROOT / "planning/refactor/tools/rf05_readiness.py"
if not MODULE.exists():
    MODULE = ROOT / "planning/refactor/rf05/drafts/rf05_readiness.py.draft"
namespace = {}
exec(compile(MODULE.read_text(encoding="utf-8"), str(MODULE), "exec"), namespace)
validate = namespace["validate_readiness"]
apply = namespace["apply_readiness"]


class ReadinessTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        plan = self.root / "planning/refactor"
        plan.mkdir(parents=True)
        self.wording = "Ảnh 20 MiB/video 8 GiB/SRT 10 MiB; dataset 32 GiB; upload chia phần/resume."
        (plan / "02-decision-register.md").write_text(
            "## Accepted decisions 32-44, reconfirmed 2026-09-30\n"
            "Status of every row: Accepted\n\n| ID | Meaning | Consequence |\n|---|---|---|\n"
            f"| 38 | {self.wording} | APPROVED_PILOT_CONFIG |\n\n## Next\n", encoding="utf-8")
        self.crosswalk = {"decisions": [{"id": "38", "source": "planning/refactor/02-decision-register.md",
                                          "authority": "TARGET_CONFIRMED_2026-09-30"}]}
        self.save_crosswalk()
        self.row = {"id": "FR-27", "authority": "MIXED_CONFIRMED_REFERENCE_AND_HISTORICAL_DETAIL",
                    "confirmed_reference": "PR-38", "claims": [{"id": "FR-27.C01"}, {"id": "FR-27.C02"}],
                    "missing_decision": "review remaining detail", "blocked_checkpoint": "RF-10-04 START"}
        self.scope = {"decision_id": "38", "decision_source": "planning/refactor/02-decision-register.md#accepted-decisions-32-44-reconfirmed-2026-09-30",
                      "decision_claim": self.wording, "scope": "Only confirmed size and resumable upload limits",
                      "claim_ids": ["FR-27.C01"]}
        self.ready = {"state": "READY", "approved_scopes": [{**self.scope, "claim_ids": ["FR-27.C01", "FR-27.C02"]}],
                      "required_evidence": ["Planned isolated HTTP and SQL boundary tests"]}

    def save_crosswalk(self):
        (self.root / "planning/refactor/04-source-crosswalk.json").write_text(
            json.dumps(self.crosswalk), encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def test_accepted_decision_matching_full_scope_can_be_ready(self):
        row = {**self.row, "authority": "TARGET_CONFIRMED_2026-09-30", "readiness": self.ready}
        self.assertIs(validate(row, self.root), row)

    def test_historical_full_claim_list_still_not_ready(self):
        with self.assertRaisesRegex(ValueError, "historical detail"):
            validate({**self.row, "readiness": self.ready}, self.root)

    def test_partial_mixed_scope_stays_blocked(self):
        row = {**self.row, "readiness": {"state": "BLOCKED", "approved_scopes": [self.scope],
                                        "reason": "remaining claim unconfirmed", "checkpoint": "RF-10-04 START"}}
        self.assertIs(validate(row, self.root), row)
        row["readiness"] = {"state": "READY", "approved_scopes": [self.scope],
                            "required_evidence": ["planned test"]}
        with self.assertRaisesRegex(ValueError, "partial decision"):
            validate(row, self.root)

    def test_historical_paths_do_not_grant_authority(self):
        for source in ("docs/diagram/V2/old.md", "docs/product/historical-fr-br.md"):
            invalid = copy.deepcopy(self.ready)
            invalid["approved_scopes"][0]["decision_source"] = source
            with self.subTest(source=source), self.assertRaisesRegex(ValueError, "source/anchor mismatch"):
                validate({**self.row, "readiness": invalid}, self.root)

    def test_proposed_or_unknown_decision_rejected(self):
        for authority in ("PROPOSED", "UNKNOWN"):
            self.crosswalk["decisions"][0]["authority"] = authority
            self.save_crosswalk()
            with self.subTest(authority=authority), self.assertRaisesRegex(ValueError, "not an accepted"):
                validate({**self.row, "readiness": self.ready}, self.root)

    def test_unrelated_decision_or_claim_rejected(self):
        for change, error in (({"decision_id": "39A"}, "unrelated"),
                              ({"claim_ids": ["FR-01.C01"]}, "unrelated")):
            invalid = copy.deepcopy(self.ready)
            invalid["approved_scopes"][0].update(change)
            with self.subTest(change=change), self.assertRaisesRegex(ValueError, error):
                validate({**self.row, "readiness": invalid}, self.root)

    def test_missing_source_anchor_scope_or_wording_rejected(self):
        for key, value, error in (("decision_source", None, "required"),
                                  ("decision_source", "planning/refactor/02-decision-register.md#wrong", "source/anchor"),
                                  ("scope", None, "required"), ("decision_claim", "accepted", "does not match")):
            invalid = copy.deepcopy(self.ready)
            if value is None:
                invalid["approved_scopes"][0].pop(key)
            else:
                invalid["approved_scopes"][0][key] = value
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, error):
                validate({**self.row, "readiness": invalid}, self.root)
        (self.root / "planning/refactor/02-decision-register.md").unlink()
        with self.assertRaisesRegex(ValueError, "missing decision source"):
            validate({**self.row, "readiness": self.ready}, self.root)

    def test_regeneration_preserves_valid_decision(self):
        registry = self.root / "registry.json"
        registry.write_text(json.dumps({"schema_version": 1, "decisions": {"FR-27": self.ready}}), encoding="utf-8")
        previous = self.root / "previous.json"
        previous.write_text(json.dumps({k: [] for k in ("fr", "br", "us", "pf", "nfr")}), encoding="utf-8")
        approved_row = {**self.row, "authority": "TARGET_CONFIRMED_2026-09-30"}
        first = apply([copy.deepcopy(approved_row)], self.root, registry, previous)
        previous.write_text(json.dumps({"fr": first, **{k: [] for k in ("br", "us", "pf", "nfr")}}), encoding="utf-8")
        second = apply([copy.deepcopy(approved_row)], self.root, registry, previous)
        self.assertEqual(second[0]["readiness"], self.ready)
        registry.write_text(json.dumps({"schema_version": 1, "decisions": {}}), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "missing from registry"):
            apply([copy.deepcopy(approved_row)], self.root, registry, previous)

    def test_blocked_without_approval(self):
        row = {**self.row, "readiness": {"state": "BLOCKED", "reason": "details unknown",
                                        "checkpoint": "RF-10-04 START"}}
        self.assertIs(validate(row, self.root), row)


if __name__ == "__main__":
    unittest.main()
