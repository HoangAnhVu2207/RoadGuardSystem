using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using RoadGuardSystem.BusinessObjects.Auditing;
using RoadGuardSystem.BusinessObjects.Files;
using RoadGuardSystem.Repositories.Files;
using RoadGuardSystem.Repositories.Idempotency;
using RoadGuardSystem.Repositories.Storage;
using RoadGuardSystem.aBusinessObjects.Commons;

namespace RoadGuardSystem.Repositories.Implementations.Files;

public sealed class UploadPersistenceService : IUploadRepository
{
    private const string CreateOperation = "UploadSessionCreated";
    private const string CompleteOperation = "UploadSessionCompleted";
    private readonly RoadGuardDbContext _context;
    private readonly IdempotencyOperationService _idempotency;
    private readonly IUploadObjectStorage _storage;

    public UploadPersistenceService(
        RoadGuardDbContext context,
        IdempotencyOperationService idempotency,
        IUploadObjectStorage storage)
    {
        _context = context;
        _idempotency = idempotency;
        _storage = storage;
    }

    public async Task<UploadMutationPersistenceResult> CreateAsync(
        UploadCreatePersistenceRequest request,
        CancellationToken cancellationToken = default)
    {
        if (request.SizeBytes > int.MaxValue)
        {
            return new(UploadPersistenceStatus.InvalidInput, null);
        }

        try
        {
            var outcome = await _idempotency.ExecuteAsync(
                request.ActorUserId,
                request.ProjectId,
                CreateOperation,
                request.IdempotencyKey,
                request.RequestFingerprint,
                async token =>
                {
                    var now = DateTimeOffset.UtcNow;
                    var fileId = Guid.NewGuid();
                    var objectKey = $"uploads/{fileId:N}";
                    var file = StoredFile.Create(
                        fileId,
                        objectKey,
                        request.FileName,
                        request.MediaType,
                        checked((int)request.SizeBytes),
                        request.ChecksumSha256,
                        request.ActorUserId,
                        now,
                        retentionUntil: null);
                    var session = UploadSession.Create(
                        Guid.NewGuid(),
                        fileId,
                        request.ActorUserId,
                        objectKey,
                        request.Purpose,
                        request.MediaType,
                        request.SizeBytes,
                        request.ChecksumSha256,
                        request.PartSizeBytes,
                        request.ExpiresAt);
                    _context.Files.Add(file);
                    _context.FileScopes.Add(FileScope.Create(
                        Guid.NewGuid(),
                        fileId,
                        request.ProjectId,
                        request.TargetId,
                        request.ActorUserId,
                        request.Purpose,
                        now));
                    _context.UploadSessions.Add(session);
                    _context.AuditLogs.Add(AuditLog.Create(
                        Guid.NewGuid(),
                        request.ActorUserId,
                        now,
                        "upload_session_created",
                        "UploadSession",
                        session.Id,
                        null,
                        JsonSerializer.Serialize(new { session.Id, session.FileId, request.ProjectId, request.Purpose }),
                        "Upload session created",
                        "p2-023",
                        request.CorrelationId,
                        ["id", "fileId", "projectId", "purpose"]));
                    await _context.SaveChangesAsync(token);
                    return (session.Id, JsonSerializer.Serialize(ToView(session, request.ProjectId)));
                },
                cancellationToken);

            if (outcome.Status == IdempotencyOperationStatus.Conflict)
            {
                return new(UploadPersistenceStatus.Conflict, null);
            }

            var view = JsonSerializer.Deserialize<UploadSessionPersistenceView>(outcome.OutcomeJson)
                ?? throw new InvalidOperationException("Upload session replay payload is invalid.");
            return new(outcome.Status == IdempotencyOperationStatus.Replayed ? UploadPersistenceStatus.Replayed : UploadPersistenceStatus.Success, view);
        }
        catch (ArgumentException)
        {
            return new(UploadPersistenceStatus.InvalidInput, null);
        }
    }

    public async Task<UploadSessionPersistenceView?> GetSessionAsync(Guid uploadId, CancellationToken cancellationToken = default)
    {
        var row = await (
            from session in _context.UploadSessions.AsNoTracking()
            join scope in _context.FileScopes.AsNoTracking() on session.FileId equals scope.FileId
            where session.Id == uploadId
            select new { Session = session, scope.ProjectId })
            .SingleOrDefaultAsync(cancellationToken);
        return row is null ? null : ToView(row.Session, row.ProjectId);
    }

    public async Task<UploadPartUrlsPersistenceResult> GetPartUrlsAsync(
        Guid actorUserId,
        Guid projectId,
        Guid uploadId,
        IReadOnlyList<int> partNumbers,
        string idempotencyKey,
        string requestFingerprint,
        DateTimeOffset now,
        DateTimeOffset urlExpiresAt,
        CancellationToken cancellationToken = default)
    {
        if (partNumbers.Count == 0 || partNumbers.Distinct().Count() != partNumbers.Count || partNumbers.Any(number => number < 1))
        {
            return new(UploadPersistenceStatus.InvalidInput, []);
        }

        var session = await _context.UploadSessions
            .SingleOrDefaultAsync(candidate => candidate.Id == uploadId, cancellationToken);
        if (session is null)
        {
            return new(UploadPersistenceStatus.NotFound, []);
        }

        if (session.Status is UploadSessionStatus.Verifying or UploadSessionStatus.Verified or UploadSessionStatus.Failed || now >= session.ExpiresAt)
        {
            return new(UploadPersistenceStatus.Conflict, []);
        }

        var partCount = checked((int)Math.Ceiling(session.ExpectedSizeBytes / (double)session.PartSizeBytes));
        if (partNumbers.Any(number => number > partCount))
        {
            return new(UploadPersistenceStatus.InvalidInput, []);
        }

        try
        {
            if (string.IsNullOrWhiteSpace(session.StorageUploadId))
            {
                var uploadStorageId = await _storage.InitiateAsync(session.ObjectKey, session.MediaType, cancellationToken);
                session.StartUploading(uploadStorageId, now);
            }

            await _context.SaveChangesAsync(cancellationToken);
            var outcome = await _idempotency.ExecuteAsync(
                actorUserId,
                projectId,
                "UploadPartUrlsIssued",
                idempotencyKey,
                requestFingerprint,
                async token =>
                {
                    var current = await _context.UploadSessions.SingleOrDefaultAsync(candidate => candidate.Id == uploadId, token)
                        ?? throw new UploadNotFoundException();
                    foreach (var partNumber in partNumbers)
                    {
                        var row = await _context.UploadParts.SingleOrDefaultAsync(
                            candidate => candidate.UploadSessionId == current.Id && candidate.PartNumber == partNumber,
                            token);
                        if (row is null)
                        {
                            row = UploadPart.Create(Guid.NewGuid(), current.Id, partNumber);
                            _context.UploadParts.Add(row);
                        }

                        row.RecordUrl(now, urlExpiresAt);
                    }

                    await _context.SaveChangesAsync(token);
                    return (Guid.NewGuid(), JsonSerializer.Serialize(new UploadPartUrlReceipt(
                        current.ObjectKey,
                        current.StorageUploadId!,
                        partNumbers.OrderBy(number => number).ToArray(),
                        urlExpiresAt)));
                },
                cancellationToken);
            if (outcome.Status == IdempotencyOperationStatus.Conflict)
            {
                return new(UploadPersistenceStatus.Conflict, []);
            }

            var receipt = JsonSerializer.Deserialize<UploadPartUrlReceipt>(outcome.OutcomeJson)
                ?? throw new InvalidOperationException("Upload part URL replay payload is invalid.");
            var parts = await _storage.PresignPartsAsync(receipt.ObjectKey, receipt.StorageUploadId, receipt.PartNumbers, receipt.ExpiresAt, cancellationToken);
            return new(outcome.Status == IdempotencyOperationStatus.Replayed ? UploadPersistenceStatus.Replayed : UploadPersistenceStatus.Success, parts);
        }
        catch (FileStorageException)
        {
            return new(UploadPersistenceStatus.StorageUnavailable, []);
        }
    }

    public async Task<UploadMutationPersistenceResult> CompleteAsync(
        UploadCompletePersistenceRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var outcome = await _idempotency.ExecuteAsync(
                request.ActorUserId,
                request.ProjectId,
                CompleteOperation,
                request.IdempotencyKey,
                request.RequestFingerprint,
                async token =>
                {
                    var session = await _context.UploadSessions.SingleOrDefaultAsync(candidate => candidate.Id == request.UploadId, token)
                        ?? throw new UploadNotFoundException();
                    var scope = await _context.FileScopes.AsNoTracking().SingleAsync(candidate => candidate.FileId == session.FileId, token);
                    if (!string.Equals(session.ExpectedChecksumSha256, request.ChecksumSha256, StringComparison.Ordinal))
                    {
                        throw new ArgumentException("Upload checksum does not match session expectation.");
                    }

                    var expectedPartCount = checked((int)Math.Ceiling(session.ExpectedSizeBytes / (double)session.PartSizeBytes));
                    if (request.Parts.Count != expectedPartCount || request.Parts.Select(part => part.PartNumber).Distinct().Count() != expectedPartCount || request.Parts.Any(part => part.PartNumber < 1 || part.PartNumber > expectedPartCount))
                    {
                        throw new ArgumentException("Upload parts are incomplete.");
                    }

                    if (!session.RowVersion.SequenceEqual(Convert.FromBase64String(request.ExpectedVersion)))
                    {
                        throw new UploadConcurrencyException();
                    }

                    session.StartVerification(request.ExpectedVersion, DateTimeOffset.UtcNow);
                    foreach (var completedPart in request.Parts)
                    {
                        var part = await _context.UploadParts.SingleOrDefaultAsync(
                            candidate => candidate.UploadSessionId == session.Id && candidate.PartNumber == completedPart.PartNumber,
                            token) ?? throw new ArgumentException("Upload part was not issued.");
                        part.RecordCompletion(completedPart.ETag);
                    }

                    var now = DateTimeOffset.UtcNow;
                    _context.AuditLogs.Add(AuditLog.Create(
                        Guid.NewGuid(), request.ActorUserId, now, "upload_verification_requested", "UploadSession", session.Id,
                        null, JsonSerializer.Serialize(new { session.Id, session.FileId }), "Upload verification requested", "p2-025", request.CorrelationId,
                        ["id", "fileId"]));
                    await _context.SaveChangesAsync(token);
                    return (Guid.NewGuid(), JsonSerializer.Serialize(ToView(session, scope.ProjectId)));
                },
                cancellationToken);

            if (outcome.Status == IdempotencyOperationStatus.Conflict)
            {
                return new(UploadPersistenceStatus.Conflict, null);
            }

            var view = JsonSerializer.Deserialize<UploadSessionPersistenceView>(outcome.OutcomeJson)
                ?? throw new InvalidOperationException("Upload completion replay payload is invalid.");
            return new(outcome.Status == IdempotencyOperationStatus.Replayed ? UploadPersistenceStatus.Replayed : UploadPersistenceStatus.Success, view);
        }
        catch (UploadNotFoundException)
        {
            return new(UploadPersistenceStatus.NotFound, null);
        }
        catch (FormatException)
        {
            return new(UploadPersistenceStatus.ConcurrencyConflict, null);
        }
        catch (UploadConcurrencyException)
        {
            return new(UploadPersistenceStatus.ConcurrencyConflict, null);
        }
        catch (InvalidOperationException)
        {
            return new(UploadPersistenceStatus.Conflict, null);
        }
        catch (ArgumentException)
        {
            return new(UploadPersistenceStatus.InvalidInput, null);
        }
        catch (DbUpdateConcurrencyException)
        {
            _context.ChangeTracker.Clear();
            return new(UploadPersistenceStatus.ConcurrencyConflict, null);
        }
    }

    public async Task<FileMetadataPersistenceView?> GetFileMetadataAsync(Guid fileId, CancellationToken cancellationToken = default)
    {
        var row = await (
            from file in _context.Files.AsNoTracking()
            join scope in _context.FileScopes.AsNoTracking() on file.Id equals scope.FileId
            join session in _context.UploadSessions.AsNoTracking() on file.Id equals session.FileId
            where file.Id == fileId
            select new { File = file, Scope = scope, Session = session })
            .SingleOrDefaultAsync(cancellationToken);
        return row is null
            ? null
            : new FileMetadataPersistenceView(
                row.File.Id,
                row.Scope.OwnerUserId,
                row.Scope.ProjectId,
                row.File.StorageUri,
                row.Session.Status.ToString().ToUpperInvariant(),
                row.File.Checksum,
                row.File.MimeType,
                row.File.SizeBytes,
                Convert.ToBase64String(row.Session.RowVersion));
    }

    public Task<Stream> OpenFileAsync(string objectKey, CancellationToken cancellationToken = default)
        => _storage.OpenReadAsync(objectKey, cancellationToken);

    public async Task<UploadPersistenceStatus> VerifyNextAsync(CancellationToken cancellationToken = default)
    {
        var session = await _context.UploadSessions
            .OrderBy(candidate => candidate.ExpiresAt)
            .FirstOrDefaultAsync(candidate => candidate.Status == UploadSessionStatus.Verifying, cancellationToken);
        if (session is null)
        {
            return UploadPersistenceStatus.NotFound;
        }

        var parts = await _context.UploadParts
            .Where(part => part.UploadSessionId == session.Id)
            .OrderBy(part => part.PartNumber)
            .ToListAsync(cancellationToken);
        if (string.IsNullOrWhiteSpace(session.StorageUploadId) || parts.Count == 0 || parts.Any(part => string.IsNullOrWhiteSpace(part.ETag)))
        {
            session.MarkFailed("upload_parts_missing");
            await _context.SaveChangesAsync(cancellationToken);
            return UploadPersistenceStatus.InvalidInput;
        }

        try
        {
            var verification = await _storage.CompleteAndVerifyAsync(
                session.ObjectKey,
                session.StorageUploadId,
                parts.Select(part => new CompletedStoragePart(part.PartNumber, part.ETag!)).ToArray(),
                cancellationToken);
            if (verification.SizeBytes != session.ExpectedSizeBytes)
            {
                session.MarkFailed("file_size_mismatch");
            }
            else if (!CryptographicOperations.FixedTimeEquals(
                         Convert.FromHexString(verification.ChecksumSha256),
                         Convert.FromHexString(session.ExpectedChecksumSha256)))
            {
                session.MarkFailed("file_checksum_mismatch");
            }
            else if (!string.Equals(verification.MimeType, session.MediaType, StringComparison.OrdinalIgnoreCase))
            {
                session.MarkFailed("file_mime_mismatch");
            }
            else
            {
                session.MarkVerified();
            }

            await _context.SaveChangesAsync(cancellationToken);
            return UploadPersistenceStatus.Success;
        }
        catch (FileStorageException)
        {
            _context.ChangeTracker.Clear();
            return UploadPersistenceStatus.StorageUnavailable;
        }
    }

    private static UploadSessionPersistenceView ToView(UploadSession session, Guid projectId)
        => new(
            session.Id,
            session.FileId,
            session.OwnerUserId,
            projectId,
            session.ObjectKey,
            session.Status.ToString().ToUpperInvariant(),
            session.PartSizeBytes,
            session.ExpiresAt,
            Convert.ToBase64String(session.RowVersion));

    private sealed class UploadNotFoundException : Exception;

    private sealed class UploadConcurrencyException : Exception;

    private sealed record UploadPartUrlReceipt(
        string ObjectKey,
        string StorageUploadId,
        IReadOnlyList<int> PartNumbers,
        DateTimeOffset ExpiresAt);
}
