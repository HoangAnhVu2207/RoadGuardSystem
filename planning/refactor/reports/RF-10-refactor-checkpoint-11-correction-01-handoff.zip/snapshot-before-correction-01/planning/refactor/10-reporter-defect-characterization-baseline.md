# RF-10-06-C01 Reporter/Defect Characterization Baseline

## Provenance

- Branch: `anh`; local HEAD: `2efc8a5775f834c7f0fe37cc0ce703011649e1f1`; `origin/anh` was not refreshed for this slice. The working tree was already dirty and all pre-existing paths were preserved.
- Scope: current implemented Reporter onboarding, processing-job read authorization/projection, defect/AI entity provenance, and caller inventory. No production, schema, migration, contract, CI or shared database change.
- Evidence labels: `SOURCE_INSPECTED` means source/caller search; `RUNTIME_TESTED` means the focused isolated SQL Server API test; `NOT_IMPLEMENTED` means no production path was found in this repository; `NOT_VERIFIED` means an external consumer/deployment or unexercised behavior was not proved.

## Current inventory

| Area | Current source and callers | Result |
|---|---|---|
| Reporter onboarding | `ReporterRegistrationsController` -> `IIdentityOnboardingService`; register/verify/resend routes are present. Existing onboarding tests cover OTP and resend. | `SOURCE_INSPECTED`; historical/current onboarding evidence is separate from this C01. |
| Processing-job read | `ProcessingV2Controller.GetProcessingJob` -> `ProcessingV2Service.GetAsync` -> `ProcessingV2PersistenceService.GetAsync`. Service accepts Supervisor, ProjectManager and DroneOperator, then applies project scope. | `RUNTIME_TESTED`: Supervisor created a job through `POST /api/v1/processing-jobs`; Supervisor GET returned 200; Reporter and a PM with membership only in project B returned 403 with `access_forbidden`. |
| Projection/privacy | Response fields observed: `id`, `status`, nullable `resultId`, `attemptNumber`, `version`, `jobType`, nullable `error`; `ETag` is present. Raw manifest/detection payload and fixture email/secret sentinels were absent. | `RUNTIME_TESTED` for this response, not a system-wide privacy claim. |
| Durable effects of read | Fresh contexts compared ProcessingJob status/rowversion, attempts, detections, ProcessingJob audit rows, job-correlated outbox rows, and project-scoped `ProcessingJobCreated` receipts before/after each GET. | `RUNTIME_TESTED`: no change observed for success or denied reads. |
| Reporter report/case | No `Report`/`IncidentCase` controller or production service caller was found; draft operation IDs D034-D044 have no implementation. | `NOT_IMPLEMENTED`; no HTTP coverage claimed. |
| Defect/PM review | `Defect`, `AIDetection`, verification entities and `DetectionReviewPersistenceService` exist. No production controller/service caller for PM defect decision was found. | `SOURCE_INSPECTED` / `NOT_IMPLEMENTED` for PM HTTP workflow. P232 repository-direct evidence is historical/runtime for persistence only, not PM HTTP authorization. |
| Label/training export | No production label approval or training-export implementation/caller was found. | `NOT_IMPLEMENTED`; 34A remains a target requirement only. |

## Characterized current behavior

The processing-job read route returns `200 application/json` for a scoped Supervisor and includes an `ETag` derived from the job version. A Reporter is rejected before repository read with `403 application/problem+json` and code `access_forbidden`. A ProjectManager whose active membership is only in another project receives the same `403`/`access_forbidden`. This records implementation behavior; it does not decide whether future Reporter visibility should be 403, 404, or another policy.

The test creates its job through the production HTTP create path. The dataset/model/road/survey rows are isolated fixture prerequisites; no job state or defect result was fabricated by direct SQL. The read assertions do not require a completed detection, so no callback is invented for this C01.

## Findings and limits

- `RF1006-C01-F01` (medium): processing-job read projection and scope behavior are implemented and characterized for three roles. Evidence: `ProcessingV2Controller.cs`, `ProcessingV2Service.cs`, `ProcessingV2PersistenceService.cs`, and the focused API test.
- `RF1006-C01-F02` (high): report/case, PM defect review and label/export HTTP paths are absent from the repository search. Do not count their absence as a successful workflow; feature slices remain open.
- `RF1006-C01-F03` (medium): P232 persistence tests prove entity/repository transitions only; no production caller or HTTP PM authorization was found.
- Accepted 33A/34A define requirements (project-scoped candidate matching and PM-approved labels) but do not establish a wire contract, visibility policy, or implementation.
- External Web/Android/AI consumers, deployed rows, provider behavior, completed-job public projection, and production dispatcher reachability remain `NOT_VERIFIED`.

## Next slice

Keep current onboarding and processing read behavior provisionally. RF-10-06-F/G work requires Q-RF02-07 privacy/routing and matching decisions, an approved case/label contract, and consumer ownership. No F/G implementation or 10-06-C02 is started by this baseline.
