# RF-10-03-C02 Survey Request, Task and Assignment Baseline

## Scope and evidence

- Branch `anh`, HEAD `2efc8a5775f834c7f0fe37cc0ce703011649e1f1`; working tree was already dirty. This is current local characterization only; no production, contract, schema, migration, CI or shared database change was made.
- `CURRENT_VERIFIED`: `SurveyPlanningController.CreateRequest` creates a `SurveyRequest` through the old road-section route. `SurveyV2Controller.CreateTask` creates a `SurveyRequest` plus an active `SurveyAssignment`; `GetTask` joins the assignment-backed path.
- `RUNTIME_TESTED`: final `Rf1003RequestTaskAssignmentCharacterizationTests` passed 1/1 on the owned SQL Server API fixture. `old request -> V2 GET` returned 404; assigned operator `V2 task -> GET` returned 200 with the same task/operator/status; Reporter returned 403; a manager acting on a second project returned 403; replay returned the same task and SQL counts remained unchanged; missing idempotency header returned 428. Durable request/assignment state was checked in a new DbContext.
- `HISTORICAL_RUNTIME`: P122 and P2 existing tests remain separate-family evidence and are not counted as this cross-family test.
- `NOT_VERIFIED/N/A`: no production route was found that assigns an old request; no reverse old mutation route exists for a V2 task; external clients, deployed rows and coexistence policy remain unknown.

## Current matrix

| Flow | Route and actor | Durable writes | Read/mutation result | Replay/precondition | Status |
|---|---|---|---|---|---|
| Old request | `POST /api/v1/projects/{project}/road-sections/{section}/survey-requests`, authenticated project manager | One `SurveyRequest`; no assignment | V2 task GET on the same request id returned 404 | Old `operationId`; no V2 `Idempotency-Key` or `If-Match` | CURRENT_VERIFIED + RUNTIME_TESTED |
| V2 task | `POST /api/v1/projects/{project}/survey-tasks`, authenticated project manager, operator must be active drone operator | One `SurveyRequest` and one active `SurveyAssignment`, same project | Assigned operator GET returns 200; Reporter and manager outside the task project return 403 | Required `Idempotency-Key`; replay returns same task without extra request/assignment; task row has rowversion; missing key returns 428 | CURRENT_VERIFIED + RUNTIME_TESTED |
| Assignment lifecycle | `SurveyAssignmentService`/`SurveyAssignmentPersistenceService` support reassignment; no old-request assignment route was found | Reassignment ends prior assignment and adds replacement plus audit/outbox | No old-request production path was found in repo | Concurrency/operation receipt handled by repository path; not exercised for old request | SOURCE_INSPECTED; old path NOT_VERIFIED |

## Findings

- `RF10-03-C02-F01` (high): old request and V2 task share `SurveyRequests` but differ in assignment creation and V2 read visibility. Keep both paths; do not infer coexistence or backfill policy.
- `RF10-03-C02-F02` (medium): V2 task creation is the reachable production path that establishes `SurveyAssignment`; no valid old-request assignment creator was identified in the repository. Treat old-to-task linkage as UNKNOWN, not as an absent external consumer.
- `RF10-03-C02-F03` (medium): V2 idempotency/precondition headers are mandatory while old request uses body `operationId`; no cross-family deduplication claim is supported.
- `RF10-03-C02-F04` (medium): the tested manager can read the task it created, while Reporter and a manager outside the task project are forbidden. This is current authorization behavior; no target policy is inferred.
- `RF10-03-C02-F05` (medium): assignment reassignment and stale `If-Match` behavior are covered by the existing P2 runtime test (`P2SurveyV2ApiTests.SurveyV2Endpoints_CreateReplayPostponeWithConcurrencyAndReadScope`); C02 did not invent an old-request assignment path.

## Decisions and limits

Q-RF02-03 remains the gate for row ownership, old-row exposure and any compatibility/backfill. No Q11 or target coexistence rule was accepted. F/G work, schema changes and consumer migration are outside C02.
