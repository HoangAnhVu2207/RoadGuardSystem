NEW FILE: planning/refactor/reports/RF-10-06-checkpoint-11-README.md
