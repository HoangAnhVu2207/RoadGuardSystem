using RoadGuardSystem.DTOs.Projects;
using RoadGuardSystem.Repositories.Projects;
using RoadGuardSystem.aBusinessObjects.Commons;

namespace RoadGuardSystem.Services.Projects;

public sealed class ProjectWorkPackageService : IProjectWorkPackageService
{
    private readonly IProjectWorkPackageRepository _readModel;

    public ProjectWorkPackageService(IProjectWorkPackageRepository readModel)
    {
        _readModel = readModel;
    }

    public async Task<ProjectWorkPackageResponseDto?> GetAsync(
        Guid projectId,
        UserRoleCode accessRole,
        CancellationToken cancellationToken = default)
    {
        var result = await _readModel.ReadAsync(projectId, cancellationToken);
        return result is null
            ? null
            : new ProjectWorkPackageResponseDto(
                result.ProjectId,
                result.ProjectCode,
                result.Name,
                result.Description,
                result.EngineeringUtmSrid,
                result.Status.ToString().ToUpperInvariant(),
                result.StartDate,
                result.EndDate,
                accessRole.ToDbCode(),
                Convert.ToBase64String(result.RowVersion),
                result.RoadSections.Select(MapRoadSection).ToArray(),
                result.Warranties.Select(MapWarranty).ToArray());
    }

    private static RoadSectionWorkPackageDto MapRoadSection(RoadSectionWorkPackageReadResult section) => new(
        section.RoadSectionId,
        section.Code,
        section.Name,
        section.CurrentVersionId,
        section.VersionNo,
        section.GeometryWkt,
        section.Srid,
        section.EffectiveFrom,
        section.ChangeReason);

    private static WarrantyWorkPackageDto MapWarranty(WarrantyWorkPackageReadResult warranty) => new(
        warranty.WarrantyId,
        warranty.RoadSectionId,
        warranty.HandoverDocumentId,
        warranty.HandoverDate,
        warranty.WarrantyStartDate,
        warranty.WarrantyEndDate,
        warranty.RetainedValue,
        warranty.Scope.ToApiCode(),
        warranty.Terms,
        warranty.SourceDocumentId,
        warranty.Status.ToString().ToUpperInvariant());
}
