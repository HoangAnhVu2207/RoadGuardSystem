using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using RoadGuardSystem.ApiTests.Infrastructure;
using RoadGuardSystem.BusinessObjects.Projects;
using RoadGuardSystem.aBusinessObjects.Commons;
using Xunit;

namespace RoadGuardSystem.ApiTests.Surveys;

[Trait("TaskId", "RF-10-03-C02")]
[Collection(AuthenticationApiFixture.Name)]
public sealed class Rf1003RequestTaskAssignmentCharacterizationTests
{
    private readonly AuthenticationSqlServerFixture _sql;

    public Rf1003RequestTaskAssignmentCharacterizationTests(AuthenticationSqlServerFixture sql) => _sql = sql;

    [Fact]
    public async Task OldRequestAndV2TaskUseDistinctRoutesAndV2CreatesAssignment()
    {
        var supervisor = await _sql.CreateUserAsync($"rf1003c02_sup_{Guid.NewGuid():N}", "Current1!", UserRoleCode.Supervisor);
        var manager = await _sql.CreateUserAsync($"rf1003c02_pm_{Guid.NewGuid():N}", "Current1!", UserRoleCode.ProjectManager);
        var operatorUser = await _sql.CreateUserAsync($"rf1003c02_op_{Guid.NewGuid():N}", "Current1!", UserRoleCode.DroneOperator);
        var replacementOperator = await _sql.CreateUserAsync($"rf1003c02_op2_{Guid.NewGuid():N}", "Current1!", UserRoleCode.DroneOperator);
        var secondManager = await _sql.CreateUserAsync($"rf1003c02_pm2_{Guid.NewGuid():N}", "Current1!", UserRoleCode.ProjectManager);
        var reporter = await _sql.CreateUserAsync($"rf1003c02_reporter_{Guid.NewGuid():N}", "Current1!", UserRoleCode.Reporter);
        await using var factory = new AuthenticationWebApplicationFactory(_sql.ConnectionString);
        using var client = factory.CreateClient(new() { BaseAddress = new Uri("https://localhost") });

        await AuthenticateAsync(client, supervisor.UserName!);
        var projectId = await CreateProjectAsync(client, manager.Id);
        var secondProjectId = await CreateProjectAsync(client, secondManager.Id);
        var routeVersionId = await CreateRoadSectionAsync(client, projectId);
        var segmentSetId = Guid.NewGuid();
        var segmentId = Guid.NewGuid();
        await using (var setup = _sql.CreateDbContext())
        {
            setup.RoadSegmentSets.Add(RoadSegmentSet.Create(segmentSetId, routeVersionId));
            setup.RoadSegments.Add(RoadSegment.Create(segmentId, segmentSetId, routeVersionId, 1));
            await setup.SaveChangesAsync();
        }

        await AuthenticateAsync(client, manager.UserName!);
        var oldResponse = await client.PostAsJsonAsync($"/api/v1/projects/{projectId}/road-sections/{await RoadSectionIdAsync(routeVersionId)}/survey-requests", new
        {
            roadSectionVersionId = routeVersionId,
            surveyPlanId = (Guid?)null,
            surveyType = 2,
            dueAt = "2026-10-05T10:00:00Z",
            outputRequirements = "{\"formats\":[\"video\"]}",
            operationId = Guid.NewGuid()
        });
        oldResponse.StatusCode.Should().Be(HttpStatusCode.Created);
        var oldBody = await oldResponse.Content.ReadFromJsonAsync<JsonElement>();
        var oldRequestId = oldBody.GetProperty("requestId").GetGuid();

        var oldAsV2 = await client.GetAsync($"/api/v1/survey-tasks/{oldRequestId}");
        oldAsV2.StatusCode.Should().Be(HttpStatusCode.NotFound, "V2 task lookup requires an assignment-backed task");

        var scope = new[] { new { routeVersionId, segmentSetId, segmentIds = new[] { segmentId }, targetBand = "SURFACE" } };
        using var createTask = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/projects/{projectId}/survey-tasks")
        {
            Content = JsonContent.Create(new { scope, surveyType = "BASELINE", operatorId = operatorUser.Id, dueAt = "2026-10-06T10:00:00Z", accessPoint = (object?)null })
        };
        createTask.Headers.Add("Idempotency-Key", "rf1003-c02-task-001");
        var taskResponse = await client.SendAsync(createTask);
        taskResponse.StatusCode.Should().Be(HttpStatusCode.Created);
        var taskBody = await taskResponse.Content.ReadFromJsonAsync<JsonElement>();
        var taskId = taskBody.GetProperty("id").GetGuid();
        taskBody.GetProperty("operatorId").GetGuid().Should().Be(operatorUser.Id);
        taskBody.GetProperty("projectId").GetGuid().Should().Be(projectId);
        var initialVersion = taskBody.GetProperty("version").GetString();
        initialVersion.Should().NotBeNullOrWhiteSpace();

        await AuthenticateAsync(client, operatorUser.UserName!);
        var assignedRead = await client.GetAsync($"/api/v1/survey-tasks/{taskId}");
        assignedRead.StatusCode.Should().Be(HttpStatusCode.OK);
        var assignedBody = await assignedRead.Content.ReadFromJsonAsync<JsonElement>();
        assignedBody.GetProperty("id").GetGuid().Should().Be(taskId);
        assignedBody.GetProperty("operatorId").GetGuid().Should().Be(operatorUser.Id);
        assignedBody.GetProperty("status").GetString().Should().Be("NEW_ASSIGNED");

        await AuthenticateAsync(client, reporter.UserName!);
        var wrongRole = await client.GetAsync($"/api/v1/survey-tasks/{taskId}");
        wrongRole.StatusCode.Should().Be(HttpStatusCode.Forbidden);

        await AuthenticateAsync(client, manager.UserName!);
        var beforeWrongProject = await ReadCountsAsync(projectId, taskId);
        using var wrongProjectRequest = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/projects/{secondProjectId}/survey-tasks")
        {
            Content = JsonContent.Create(new { scope, surveyType = "BASELINE", operatorId = operatorUser.Id, dueAt = "2026-10-06T10:00:00Z", accessPoint = (object?)null })
        };
        wrongProjectRequest.Headers.Add("Idempotency-Key", "rf1003-c02-wrong-project");
        var wrongProject = await client.SendAsync(wrongProjectRequest);
        wrongProject.StatusCode.Should().Be(HttpStatusCode.Forbidden);

        var beforeReassign = await ReadLifecycleAsync(taskId);
        using var reassign = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/survey-tasks/{taskId}/reassign")
        {
            Content = JsonContent.Create(new { operatorId = replacementOperator.Id, reason = "Operator coverage changed", dueAt = "2026-10-07T10:00:00Z" })
        };
        reassign.Headers.Add("Idempotency-Key", "rf1003-c02-reassign-001");
        reassign.Headers.Add("If-Match", $"\"{initialVersion}\"");
        var reassigned = await client.SendAsync(reassign);
        reassigned.StatusCode.Should().Be(HttpStatusCode.OK);
        var reassignedBody = await reassigned.Content.ReadFromJsonAsync<JsonElement>();
        reassignedBody.GetProperty("operatorId").GetGuid().Should().Be(replacementOperator.Id);
        reassignedBody.GetProperty("status").GetString().Should().Be("REASSIGNED");
        var reassignedVersion = reassignedBody.GetProperty("version").GetString();
        reassignedVersion.Should().NotBeNullOrWhiteSpace();

        var afterReassign = await ReadLifecycleAsync(taskId);
        afterReassign.ActiveOperator.Should().Be(replacementOperator.Id);
        afterReassign.EndedOperator.Should().Be(operatorUser.Id);
        afterReassign.Assignments.Should().Be(beforeReassign.Assignments + 1);
        afterReassign.Audits.Should().Be(beforeReassign.Audits + 1);
        afterReassign.Outbox.Should().Be(beforeReassign.Outbox, "the SurveyV2 task mutation path does not enqueue an outbox message");

        using var staleReassign = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/survey-tasks/{taskId}/reassign")
        {
            Content = JsonContent.Create(new { operatorId = operatorUser.Id, reason = "Stale precondition" })
        };
        staleReassign.Headers.Add("Idempotency-Key", "rf1003-c02-reassign-stale");
        staleReassign.Headers.Add("If-Match", $"\"{initialVersion}\"");
        var stale = await client.SendAsync(staleReassign);
        stale.StatusCode.Should().Be(HttpStatusCode.PreconditionFailed);

        using var replayReassign = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/survey-tasks/{taskId}/reassign")
        {
            Content = JsonContent.Create(new { operatorId = replacementOperator.Id, reason = "Operator coverage changed", dueAt = "2026-10-07T10:00:00Z" })
        };
        replayReassign.Headers.Add("Idempotency-Key", "rf1003-c02-reassign-001");
        replayReassign.Headers.Add("If-Match", $"\"{initialVersion}\"");
        var replayReassignment = await client.SendAsync(replayReassign);
        replayReassignment.StatusCode.Should().Be(HttpStatusCode.OK);
        (await replayReassignment.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("operatorId").GetGuid().Should().Be(replacementOperator.Id);
        var afterReplayReassign = await ReadLifecycleAsync(taskId);
        afterReplayReassign.Assignments.Should().Be(afterReassign.Assignments);
        afterReplayReassign.Audits.Should().Be(afterReassign.Audits);
        afterReplayReassign.Outbox.Should().Be(afterReassign.Outbox);

        using var replayRequest = new HttpRequestMessage(HttpMethod.Post, $"/api/v1/projects/{projectId}/survey-tasks")
        {
            Content = JsonContent.Create(new { scope, surveyType = "BASELINE", operatorId = operatorUser.Id, dueAt = "2026-10-06T10:00:00Z", accessPoint = (object?)null })
        };
        replayRequest.Headers.Add("Idempotency-Key", "rf1003-c02-task-001");
        var replay = await client.SendAsync(replayRequest);
        replay.StatusCode.Should().Be(HttpStatusCode.Created);
        (await replay.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetGuid().Should().Be(taskId);

        var missingKey = await client.SendAsync(new HttpRequestMessage(HttpMethod.Post, $"/api/v1/projects/{projectId}/survey-tasks")
        {
            Content = JsonContent.Create(new { scope, surveyType = "BASELINE", operatorId = operatorUser.Id, dueAt = "2026-10-06T10:00:00Z", accessPoint = (object?)null })
        });
        missingKey.StatusCode.Should().Be(HttpStatusCode.PreconditionRequired);

        await using var verification = _sql.CreateDbContext();
        var oldRequest = await verification.SurveyRequests.AsNoTracking().SingleAsync(item => item.Id == oldRequestId);
        oldRequest.ProjectId.Should().Be(projectId);
        var task = await verification.SurveyRequests.AsNoTracking().SingleAsync(item => item.Id == taskId);
        task.ProjectId.Should().Be(projectId);
        var assignment = await verification.SurveyAssignments.AsNoTracking().SingleAsync(item => item.SurveyRequestId == taskId && item.EndedAt == null);
        assignment.OperatorUserId.Should().Be(replacementOperator.Id);
        (await verification.SurveyAssignments.AsNoTracking().CountAsync(item => item.SurveyRequestId == oldRequestId)).Should().Be(0);
        (await verification.SurveyRequests.AsNoTracking().CountAsync(item => item.ProjectId == projectId)).Should().Be(beforeWrongProject.Requests);
        (await verification.SurveyAssignments.AsNoTracking().CountAsync(item => item.SurveyRequestId == taskId)).Should().Be(beforeWrongProject.Assignments + 1);
        task.RowVersion.Should().NotBeNullOrEmpty();
    }

    private async Task<(int Requests, int Assignments)> ReadCountsAsync(Guid projectId, Guid taskId)
    {
        await using var context = _sql.CreateDbContext();
        return (
            await context.SurveyRequests.AsNoTracking().CountAsync(item => item.ProjectId == projectId),
            await context.SurveyAssignments.AsNoTracking().CountAsync(item => item.SurveyRequestId == taskId));
    }

    private async Task<(int Assignments, int Audits, int Outbox, Guid ActiveOperator, Guid? EndedOperator)> ReadLifecycleAsync(Guid taskId)
    {
        await using var context = _sql.CreateDbContext();
        var assignments = await context.SurveyAssignments.AsNoTracking().Where(item => item.SurveyRequestId == taskId).OrderBy(item => item.AssignedAt).ToListAsync();
        return (
            assignments.Count,
            await context.AuditLogs.AsNoTracking().CountAsync(item => item.EntityId == taskId),
            await context.OutboxMessages.AsNoTracking().CountAsync(item => item.CorrelationId == taskId),
            assignments.Single(item => item.EndedAt == null).OperatorUserId,
            assignments.SingleOrDefault(item => item.EndedAt != null)?.OperatorUserId);
    }

    private async Task<Guid> CreateProjectAsync(HttpClient client, Guid managerId)
    {
        var response = await client.PostAsJsonAsync("/api/v1/projects", new { projectCode = $"RF1003C02-{Guid.NewGuid():N}", name = "RF-10-03-C02", engineeringUtmSrid = 32648, startDate = "2026-09-01", endDate = "2027-09-01", primaryProjectManagerUserId = managerId, handover = new { documentNo = $"HD-{Guid.NewGuid():N}", handoverDate = "2026-08-31" }, operationId = Guid.NewGuid() });
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        return (await response.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("projectId").GetGuid();
    }

    private async Task<Guid> CreateRoadSectionAsync(HttpClient client, Guid projectId)
    {
        var response = await client.PostAsJsonAsync($"/api/v1/projects/{projectId}/road-sections", new { code = $"RS-{Guid.NewGuid():N}", srid = 32648, coordinates = new[] { new { x = 500000d, y = 1100000d }, new { x = 500100d, y = 1100100d } }, effectiveFrom = "2026-09-21T08:00:00+07:00", changeReason = "C02", operationId = Guid.NewGuid() });
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        return (await response.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("roadSectionVersionId").GetGuid();
    }

    private async Task<Guid> RoadSectionIdAsync(Guid versionId)
    {
        await using var context = _sql.CreateDbContext();
        return await context.RoadSectionVersions.Where(value => value.Id == versionId).Select(value => value.RoadSectionId).SingleAsync();
    }

    private static async Task AuthenticateAsync(HttpClient client, string username)
    {
        var login = await client.PostAsJsonAsync("/api/v1/auth/login", new { email = AuthenticationSqlServerFixture.EmailFor(username), password = "Current1!" });
        login.EnsureSuccessStatusCode();
        var body = await login.Content.ReadFromJsonAsync<JsonElement>();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", body.GetProperty("accessToken").GetString());
    }
}
