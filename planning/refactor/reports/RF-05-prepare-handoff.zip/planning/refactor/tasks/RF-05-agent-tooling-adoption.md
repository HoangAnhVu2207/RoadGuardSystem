# RF-05: Prepare and conditionally activate new guidance/tooling

- **Status/checkpoint:** PREPARE DONE on local anh at 2efc8a5775f834c7f0fe37cc0ce703011649e1f1; ACTIVATION NOT STARTED, awaiting explicit owner acceptance of planning/refactor/rf05/target-manifest.json and activation-plan.md. RF-05 overall remains PARTIAL until activation. Report: planning/refactor/reports/RF-05.md. No active guidance/CI/validator was changed.
- **Goal:** write proposed root `AGENTS.md`/`.agents/` guidance and switch document/tool validators/CI only after the user accepts the exact replacement set. One active authority at completion.
- **In scope:** guidance files, manifest, source-routing/report template, path validator, docs/contract guards, CI invocation and crosswalk. **Out of scope:** runtime code, migrations, business decisions, old docs/ADR deletion, framework/package upgrade.
- **Dependencies/decisions:** RF-04 content and old-path map complete; explicit user acceptance for activation and CI/guide replacement. If absent, finish drafts and mark Partial rather than activate. No Q-RF02 choice is made by guidance.
- **Read first:** `03-agent-design.md`, `03-documentation-design.md`, `00-tooling-dependencies.md`, RF-04 manifest; inspect existing `Verify-P102Docs.ps1`, `Verify-AgentSetup.ps1`, V2/FE guards, `.github/workflows/ci.yml` before editing/running.
- **Likely files:** `AGENTS.md`, `.agents/README.md`, `.agents/manifest.json`, `.agents/rules/**`, `.agents/modules/**`, `tests/Documentation/**`, `tests/Tooling/**`, `.github/workflows/ci.yml`, path links. These are proposed touch points, not RF-03 changes.
- **Contract/data/consumer effect:** no public wire/schema change. Agent/CI consumers change only after acceptance; FE snapshot/lock stays unchanged unless a separately approved contract package supplies the exact version.
- **Steps:** draft full content -> compare against old guidance dependencies -> present exact diff for acceptance -> stage validator/CI/path switch as one change -> record active version/date -> check there is no conflicting active entrypoint.
- **Verify:** old and new path/ownership/link guards where applicable, CI static verifier, parsed OpenAPI/FE lock and Postman path checks; distinguish existing `CONTRACT_LOCK_MISMATCH` from new regression. Documentation/tooling validators only; no runtime suite.
- **Done when:** user acceptance recorded, one active guidance set/manifest, all new links and CI commands work, old guidance preserved as history until RF-11, no business rule duplicated as independent agent authority.
- **Recovery:** revert coordinated guidance/CI/path switch to previous working invocation and keep draft material for review; do not delete user changes or historical guidance.

## Two-developer delivery supplement

- **Proposed owner:** A: guidance/tooling; B: module-map review fixtures. Split dual-owner parent tasks into single-owner slices before edits. See [ownership plan](../03-two-developer-plan.md).
- **Pre-edit checkpoint:** record exact allowed files/symbols, read-only dependencies, shared-file reservation, baseline commit and preserved dirty changes. Record START / INTEGRATE / RELEASE gates for this slice; existing decision/data gates remain in force.
- **Independence:** use an agreed interface/version and fixture for consumer work; label test-double evidence separately. Do not claim parent Done before required real integration.
- **Self-review:** correctness pass plus ownership/consumer impact pass, safe in-scope autofix, focused verification and final diff review. Record unresolved findings.
- **Cross-owner impact:** create a note from [coordination template](../templates/coordination-note.md), recommend primary fixer and wait for the two developers to assign the overlapping change. Continue independent work; do not edit the other owner's files or duplicate their business logic.
- **Report:** [revised seven-section template](../templates/task-report.md); single-owner task may retain its existing report path, slices use `reports/<TASK-ID>-<SLICE>-<A|B>.md`. Record implementation status separately from delivery stage.

## RF-05 PREPARE checkpoint

- Inactive package: planning/refactor/rf05/drafts/, patches/, checks/, target-manifest.json, tooling-transition.md, activation-plan.md and walkthroughs.md.
- Exact target map: 15 proposed files with source/proposed hashes; 22 old discoverable guidance files proposed for relocation only after acceptance. A/B remains proposed, not assigned.
- Staging: external temporary copy, exact-hash overlay and git apply --check PASS; RF-04 generator/verifier and five RF-04 regressions PASS; five readiness regressions PASS; proposed guidance guard, YAML parse and existing CI verifier PASS. Active protected files unchanged. See checks/staging-result.json.
- Remaining: owner acceptance; activation metadata/hash, coordinated file/path switch, real CI result. RF-06 has not started. Baseline FE lock mismatch and API seeder failure remain separate.
