# Local refactor completion checklist

Status 2026-10-01: **Partial** on `anh`, local HEAD `2efc8a5` plus dirty working tree. This checklist closes only the behavior-preserving refactor stage. It does not certify Accepted 32-44 implementation, deployed compatibility, hosted CI or release.

| Gate | Evidence now | Exit action |
|---|---|---|
| Every current module classified R/C/F/G | `10-refactor-slices.md` maps RF-10-01..09 and RF-11; RF-01 R01-18/CG01-17/L01-16 map in `03-master-plan.md`. | Review each provisional RETAIN and pending C against current source, callers and focused tests. |
| Necessary R slice complete or RETAIN with reason | RF-07 mapper and RF-08 parser are Done locally; RF-08 transaction/error seams RETAIN with reason. RF-10-04 UploadService source assessment RETAIN; most other modules have pending C/R assessment. | Complete remaining C/R assessments; no forced diff. Record each decision in slice report. |
| No serious refactor regression | RF-07/08 reports contain before/after tests. RF-10-04 C01 is characterization only and exposes a pre-existing overflow 500. | Fresh affected builds/tests for any later code diff; distinguish old failures from new. |
| Behavior proof for every changed source | RF-07 6/6 P112 and RF-08 19/19 API, 17/17 SQL historical local evidence. | Re-run evidence invalidated by source/fixture drift; include HTTP body/headers/actor/scope, SQL effects as relevant. |
| Architecture/docs/test baseline current | RF-06A source-hashed inventory, RF-09 registry/gates, current R/C/F/G ledger. | Re-run schema-doc `-Check` and relevant agent/contract validators after final diff; regenerate only via tool if fingerprints stale. |
| F/G backlog and unknown consumers explicit | `11-development-plan.md`, `09-consumer-registry.md`; Web/Android/AI owner/version UNKNOWN. | Obtain owner/consumer decisions for each affected F/G package before integration/release. |
| Final scope/diff review and combined verification | Pending. RF-10-04 C01 focused API test passed; no final cross-module suite yet. | Review tracked/untracked diff against pre-existing dirty ledger, then run one combined affected suite and active docs/tooling gates. |

## 1. Backend R/C required before local refactor completion

These are local BE investigation/structure gates; missing Web/Android/AI owners or deployed audit does not block their independent START. A fixture or mock can cover a BE contract, but it is not real external integration. `10-refactor-slices.md` is the detailed source/decision map.

| Slice / module | Work remaining | Required local evidence | Actual dependency or blocker |
|---|---|---|---|
| 10-01-C01 / identity | **Done for local current-behavior characterization.** Same-account `/profile`/`/me`, separate-target reset families, bearer/refresh and OTP guards were checked with owned SQL; identity routes have no project scope. | `10-identity-characterization-baseline.md` and `reports/RF-10-01-C01.md`; final new C01 5/5, selected existing 6/6 + 2/2 + 2/2, 0 skipped. | Consumer/transport/PII choice and deployed config remain F/G under Q-RF02-02; local C is complete. |
| 10-02-C01 / project/GIS | **Done locally for current project/GIS/warranty characterization.** Membership/effective-date source and historical API/SQL evidence were reconciled; a new owned SQL HTTP test checks geometry/version round-trip and prior-version preservation. | `10-project-gis-characterization-baseline.md` and `reports/RF-10-02-C01.md`; new focused test 1/1 after final verification, reused P112/P120/P121/P211 evidence. | Route-specific Supervisor versus membership policy, real geometry samples, deployed consumers and 39A segment/publish target remain F/G/decision work. |
| 10-03-C01 / survey | **Done for local same-row plan characterization.** New focused HTTP/owned-SQL 2/2 exercises both create->other-family postpone directions, replay/key scope, stale/current version and wrong actor. | `reports/RF-10-03-C01.md` records exact row/content and F04-F06 findings. Request/task cross-family and external consumer/deployed data are not proven by this plan-only slice. | R01 RETAIN for distinct semantics; Q-RF02-03 blocks F consolidation, not this C. |
| 10-03-C02 / survey request/task and assignment | **Done locally for reachable current behavior after checkpoint-07 correction.** Old request creation, assigned V2 read, Reporter/wrong-project authorization, replay side effects, assignment persistence and missing-key behavior were checked with owned HTTP/SQL; absent old-request assignment route is recorded. | `10-survey-request-task-assignment-characterization.md`, `reports/RF-10-03-C02.md`, final API 2/2 and P211 4/4; failed correction attempts are retained. | External consumers/deployed rows and desired coexistence remain later F/G gates; Q-RF02-03 still blocks F/backfill. |
| 10-05-C01 / processing AI | **Done for reachable-state local characterization.** Retry from queued is rejected; no production transition to `RetryableFailure` was found, so A -> retry -> B -> late A cannot be executed without an artificial state write. | Fresh owned SQL 1/1: current A callback, same-key replay, new-key request, manifest/model/raw-source mismatch; fresh-context job/attempt/detection/audit/outbox/receipt reads. See `reports/RF-10-05-C01.md`. | CG11 late-A fencing remains unproven, not disproven; provider/state-failure protocol and F fix require separate decisions. |
| 10-06-C01 / Reporter/defect | Map current registration, entity and privacy/scope behavior. | Existing API/SQL wrong actor/project and public data projection baseline. | New case/label policy is F; current registration can be checked. |
| 10-07-C01 / inspection | Capture current task list/measurement provenance and no-write behavior. | HTTP actor/project tests and SQL measurement/source integrity. | Approved Fast Track dossier blocks F only. |
| 10-08-C01 / offline primitives | Compare per-command key/fingerprint/replay/stale-actor semantics across project, survey and upload. | Selected isolated SQL/API cases per caller, no universal claim from one endpoint. | Android wire blocks F sync, not local current-command audit. |
| 10-09-C01 / messaging | Trace production dispatcher caller and characterize inbox/outbox lease/receipt. | Caller graph, inbox HTTP and owned SQL crash/replay/atomicity. | Deployment operator needed to verify real dispatcher, not local source/test work. |
| 11-C01 / final local audit | Complete source/diff attribution and cross-module verification after the remaining R/C decisions. | Final allowlist, link/tool validators, affected fresh builds/tests and no serious regression. | Existing dirty work must remain separated; hosted CI belongs to release. |

RF-07/08 preserving slices and RF-10-04 C01 are complete local evidence for their named scope; RF-10-03 C00 attribution and C01 same-row plan characterization are complete locally. A pending R extraction may be closed as RETAIN only after its C comparison shows no concrete structural gain; it must not be moved into F to manufacture completion.

## 2. Later behavior/feature/bug-fix work

D-04a fixes the observed upload validation overflow under a separately agreed public error response. D-04b and other D-01..D-09 tasks implement Accepted targets or resolve gaps: cookie/profile/reset, GIS/segments, survey ownership/coverage, 8 GiB/storage/SRT, BE-AI protocol, Reporter/defect, Fast Track/repair, offline sync, dispatcher/reporting/retention. See `11-development-plan.md` for distinct contract/data/consumer gates. None is counted as an unfinished behavior-preserving extraction.

## 3. External/deployed/release evidence

Web/Android/AI consumer versions and owner sign-off, deployed SQL audit, real 8 GiB storage transfer, hosted CI, and exact retirement/release approval remain UNKNOWN/NOT RUN. They gate the affected F/G INTEGRATE or RELEASE, not all independent backend R/C work. RF-09 and RF-11 parents stay Partial for their own external/release criteria.

Only when every row above has evidence may the report say **“Refactor complete locally.”** Pending R work stays Pending/Partial, never silently becomes F. RF-09 stays Partial until its own external/deployed conditions are met. RF-11's link/index audit can proceed independently, while old-doc/ADR/route retirement and release remain G pending. The development plan may be drafted now but its execution starts only after a reviewed common baseline and separately approved F scope.

Recovery for R-only code is the isolated slice diff after checking existing dirty work; no schema or data rollback is involved. Test-only SQL resources are fixture owned. Never reset/clean this checkout to manufacture a clean baseline.
