# RF-10-06-C01 Acceptance Matrix

| Case | Source/fixture | HTTP assertion | Durable assertion | Status |
|---|---|---|---|---|
| A positive processing-job read | Supervisor creates a valid dataset/model job through `POST /api/v1/processing-jobs` | GET same job returns 200 JSON, id/status/attempt/jobType/result projection and ETag | Job/attempt/detection/audit/outbox/create-receipt snapshot unchanged | RUNTIME_TESTED |
| B Reporter role | Same job and Reporter bearer token | GET returns 403 problem JSON, code `access_forbidden` | Snapshot unchanged | RUNTIME_TESTED |
| B wrong project | PM has active membership only in project B; job belongs to project A | GET returns 403 problem JSON, code `access_forbidden` | Snapshot unchanged | RUNTIME_TESTED |
| C projection/privacy | Success body from A | Actual fields asserted; raw manifest/detection payload and fixture email/secret sentinels absent | N/A beyond A snapshot | RUNTIME_TESTED, scoped claim |
| D missing workflows | Controller/service/caller search | Report/case, PM review, label/export have no route | N/A | SOURCE_INSPECTED / NOT_IMPLEMENTED |
| Defect persistence | `P232DetectionDefectSchemaTests`, repository source | No PM HTTP assertion | Repository-direct entity/review evidence only | HISTORICAL_RUNTIME / SOURCE_INSPECTED |
