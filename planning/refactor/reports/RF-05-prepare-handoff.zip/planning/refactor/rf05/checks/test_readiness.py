"""Focused readiness regression cases, including regeneration preservation."""

import copy
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
MODULE = ROOT / "planning/refactor/tools/rf05_readiness.py"
if not MODULE.exists():
    MODULE = ROOT / "planning/refactor/rf05/drafts/rf05_readiness.py.draft"
# A .draft suffix has no import loader; execute the reviewed source in a module namespace.
namespace = {}
exec(compile(MODULE.read_text(encoding="utf-8"), str(MODULE), "exec"), namespace)
validate = namespace["validate_readiness"]
apply = namespace["apply_readiness"]


class ReadinessTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "decision.md").write_text("PR-38 accepted interpretation\n", encoding="utf-8")
        self.row = {"id": "FR-27", "authority": "MIXED_CONFIRMED_REFERENCE_AND_HISTORICAL_DETAIL",
                    "missing_decision": "review file-size detail", "blocked_checkpoint": "RF-10-04 START"}
        self.ready = {"state": "READY", "decision_source": "decision.md#PR-38",
                      "scope": "FR-27 8 GiB video requirement only",
                      "required_evidence": ["RF-06 isolated HTTP and SQL boundary tests"]}

    def tearDown(self):
        self.tmp.cleanup()

    def test_ready_with_source_scope_and_evidence(self):
        row = {**self.row, "readiness": self.ready}
        self.assertIs(validate(row, self.root), row)

    def test_ready_without_source_rejected(self):
        invalid = copy.deepcopy(self.ready)
        invalid.pop("decision_source")
        with self.assertRaisesRegex(ValueError, "decision_source"):
            validate({**self.row, "readiness": invalid}, self.root)

    def test_blocked_with_reason_and_checkpoint(self):
        row = {**self.row, "readiness": {"state": "BLOCKED", "reason": "details unknown",
                                        "checkpoint": "RF-10-04 START"}}
        self.assertIs(validate(row, self.root), row)

    def test_regeneration_preserves_recorded_ready(self):
        registry = self.root / "registry.json"
        registry.write_text(json.dumps({"schema_version": 1, "decisions": {"FR-27": self.ready}}), encoding="utf-8")
        previous = self.root / "previous.json"
        previous.write_text(json.dumps({"fr": [], "br": [], "us": [], "pf": [], "nfr": []}), encoding="utf-8")
        first = apply([dict(self.row)], self.root, registry, previous)
        previous.write_text(json.dumps({"fr": first, "br": [], "us": [], "pf": [], "nfr": []}), encoding="utf-8")
        second = apply([dict(self.row)], self.root, registry, previous)
        self.assertEqual(second[0]["readiness"], self.ready)
        registry.write_text(json.dumps({"schema_version": 1, "decisions": {}}), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "missing from registry"):
            apply([dict(self.row)], self.root, registry, previous)

    def test_historical_source_alone_rejected(self):
        row = {**self.row, "authority": "HISTORICAL_SOURCE_ONLY",
               "readiness": {**self.ready, "decision_source": "docs/diagram/old.md"}}
        (self.root / "docs/diagram").mkdir(parents=True)
        (self.root / "docs/diagram/old.md").write_text("old", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "historical document"):
            validate(row, self.root)


if __name__ == "__main__":
    unittest.main()
